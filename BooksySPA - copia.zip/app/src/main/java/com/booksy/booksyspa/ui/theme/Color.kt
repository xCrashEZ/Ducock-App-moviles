package com.booksy.booksyspa.ui.theme

import androidx.compose.ui.graphics.Color

val Primary = Color(0xFF6750A4)
val Secondary = Color(0xFF625B71)
val Tertiary = Color(0xFF7D5260)
